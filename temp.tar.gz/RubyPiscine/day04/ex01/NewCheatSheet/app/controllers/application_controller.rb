class ApplicationController < ActionController::Base
    def index
    end
end
