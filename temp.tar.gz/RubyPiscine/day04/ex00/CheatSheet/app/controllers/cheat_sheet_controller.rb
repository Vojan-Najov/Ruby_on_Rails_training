class CheatSheetController < ApplicationController
    def index
    end
end
