class NewCheatSheetController < ApplicationController
    layout "application"

    def convention
    end
  
    def console
    end
  
    def ruby
    end
  
    def ruby_concepts
    end
  
    def ruby_numbers
    end
  
    def ruby_strings
    end
  
    def ruby_arrays
    end
  
    def ruby_hashes
    end
  
    def rails_folder_structure
    end
  
    def rails_commands
    end
  
    def rails_erb
    end
  
    def editor
    end
  
    def help
    end

    def quick_search
    end
end
