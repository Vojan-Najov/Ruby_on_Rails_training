$LOAD_PATH.unshift File.expand_path("../../lib", __FILE__)
require "ft_wikipedia"

require "minitest/autorun"
